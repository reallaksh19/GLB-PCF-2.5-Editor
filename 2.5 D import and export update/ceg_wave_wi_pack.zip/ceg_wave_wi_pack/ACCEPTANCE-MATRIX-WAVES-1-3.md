# Acceptance Matrix — Waves 1, 2, and 3

## Architecture invariants

| Invariant | Wave introduced | Required result |
|---|---:|---|
| CEG is source of truth | 1 | All edits mutate CEG through command dispatcher |
| Commands are journaled | 1 | Every successful command has beforeHash and afterHash |
| Anchors are separate | 1 | Stretch/extend operate on anchor IDs |
| DXF is adapter, not model | 2 | Raw DXF is not mutated by UI/editor |
| GLB is adapter, not model | 2 | Mesh transform is not final edit source |
| DWG is converter input only | 2 | No native DWG edit path |
| Renderer is projection | 3 | RenderIndex maps CEG ↔ objects |
| UI dispatches commands | 3 | Toolbar/property/HUD do not directly mutate model/render/raw formats |

## Quantitative master gates

| Gate | Required value |
|---|---:|
| Uncaught browser console errors | 0 |
| Static violation scan | 0 violations |
| Orphan render objects | 0 |
| Invalid selected IDs after delete | 0 |
| DXF round-trip coordinate tolerance | ≤ 0.001 mm |
| Command undo hash restoration | 100% |
| Command redo hash restoration | 100% |
| Metadata-rich GLB canonical ID preservation | 100% |
| Generic mesh stretch attempts | 100% blocked with diagnostic |
| DWG without converter | 100% graceful message, no crash |

## Mock fixtures

| Fixture | Purpose |
|---|---|
| `mock-ceg-basic.json` | CEG kernel, render, interaction, UI tests |
| `mock-command-sequence.json` | command dispatch, undo/redo, hash tests |
| `mock-dxf-basic-lines.dxf` | DXF import/export round-trip |
| `mock-gltf-scene.json` | GLB/GLTF metadata/classification simulation |
| `mock-dwg-converter-response.json` | DWG converter success path simulation |

## Boundary violation patterns

Fail merge if final code violates these patterns outside explicitly allowed files:

```text
mesh.position.
rawDxf.
rawGltf.
geometry.ep1 =
geometry.ep2 =
commandJournal.push outside core/commands
```

Allowed exceptions:

```text
render/drag-preview.js may move preview objects only
formats/dxf/ceg-to-dxf.js may create raw DXF output
formats/gltf/ceg-to-gltf.js may create GLB output data
core/commands/* may append commandJournal
```

## Wave completion sequence

```text
Wave 1 complete → CEG + commands stable
Wave 2 complete → DXF/GLB/DWG adapters stable
Wave 3 complete → render/interaction/UI stable
```

No Wave 4 hardening starts until all Wave 1–3 gates pass.
