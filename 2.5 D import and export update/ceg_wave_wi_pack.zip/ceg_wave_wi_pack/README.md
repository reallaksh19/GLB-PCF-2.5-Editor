# CEG-Based DXF/GLB Static Engineering Editor — Wave 1–3 WI Pack

## Purpose

This pack converts the revised multi-agent architecture into implementation-ready work instructions for the first three waves.

The product boundary is intentionally narrow:

- Static-first DXF/GLB/GLTF engineering editor
- Optional DWG conversion only
- Basic edits only: select, move, endpoint move, extend, stretch anchors, delete, property edit, layer visibility
- No native DWG editing
- No full CAD replacement
- No AutoLISP/macro engine in Waves 1–3

## Wave grouping

| Wave | Main Goal | Agents |
|---|---|---|
| Wave 1 | Contract + Canonical Edit Graph + command kernel + QA fixtures | AI-0, AI-1, AI-2, AI-9 |
| Wave 2 | Format intake/export: DXF, GLB/GLTF, optional DWG converter client | AI-3, AI-4, AI-5, AI-9 |
| Wave 3 | Render projection + interaction/HUD + panels/UI shell + static smoke | AI-6, AI-7, AI-8, AI-9 |

## Non-negotiable architecture rule

All final edits must follow this route:

```text
UI / HUD / Grip / Property Panel
  ↓
dispatchCommand()
  ↓
Canonical Edit Graph mutation
  ↓
model-changed event
  ↓
Render Projection update
  ↓
export from CEG
```

Forbidden final edit paths:

```text
UI → mesh.position mutation
UI → raw DXF mutation
renderer → commandJournal mutation
format adapter → DOM toolbar mutation
```

## Files in this pack

- `WI-WAVE-1-CONTRACT-CEG-COMMAND-KERNEL.md`
- `WI-WAVE-2-FORMAT-ADAPTERS-DXF-GLB-DWG.md`
- `WI-WAVE-3-RENDER-INTERACTION-UI.md`
- `ACCEPTANCE-MATRIX-WAVES-1-3.md`
- `fixtures/mock-ceg-basic.json`
- `fixtures/mock-dxf-basic-lines.dxf`
- `fixtures/mock-gltf-scene.json`
- `fixtures/mock-dwg-converter-response.json`
- `fixtures/mock-command-sequence.json`
