# WI — Wave 1: Contract + CEG Kernel + Command Kernel + QA Fixtures

## Wave 1 mission

Build the non-visual foundation:

```text
Contract Freeze
  ↓
Canonical Edit Graph
  ↓
Command + Geometry Operations
  ↓
Validation + Hashing
  ↓
Mock Fixtures + Unit Tests
```

Wave 1 does **not** implement DXF parsing, GLB loading, rendering, HUD, or property panel UI. It creates the stable source of truth that those later layers must consume.

---

# 1. Agents grouped in Wave 1

| Agent | Role | Can run together? | Dependency |
|---|---|---:|---|
| AI-0 | Orchestrator / Contract Gatekeeper | Starts first | None |
| AI-1 | CEG Kernel Owner | Starts after AI-0 freezes CEG contract | AI-0 |
| AI-2 | Command + Geometry Operations Owner | Starts after command and anchor contract freeze | AI-0 + AI-1 interface |
| AI-9 | QA / Fixture Owner | Starts after contract draft; updates continuously | AI-0 |

## Parallelization rule

AI-1, AI-2, and AI-9 may run together **only after** AI-0 publishes these frozen files:

```text
docs/CEG_CONTRACT.md
docs/COMMAND_CONTRACT.md
docs/EVENT_CONTRACT.md
docs/VALIDATION_CONTRACT.md
docs/ACCEPTANCE_MATRIX.md
```

No Wave 2 or Wave 3 work starts until Wave 1 pass gates are met.

---

# 2. AI-0 Work Instruction — Contract Gatekeeper

## Ownership

AI-0 owns documentation and merge approval only:

```text
docs/ARCHITECTURE.md
docs/CEG_CONTRACT.md
docs/COMMAND_CONTRACT.md
docs/EVENT_CONTRACT.md
docs/VALIDATION_CONTRACT.md
docs/MERGE_GOVERNANCE.md
docs/ACCEPTANCE_MATRIX.md
```

## Explicit boundaries

AI-0 may not implement feature code except small contract exports if required.

AI-0 must approve all changes to:

```text
core/ceg/*
core/commands/*
core/geometry/*
core/validation/*
```

## Required contract content

### CEG events

```js
export const CegEvents = Object.freeze({
  MODEL_LOADED: "ceg:model-loaded",
  MODEL_CHANGED: "ceg:model-changed",
  SELECTION_CHANGED: "ceg:selection-changed",
  COMMAND_APPLIED: "ceg:command-applied",
  VALIDATION_UPDATED: "ceg:validation-updated",
  EXPORT_COMPLETED: "ceg:export-completed"
});
```

### CEG schema version

```js
export const CEG_SCHEMA_VERSION = "CEG-1.0";
```

### Contract rule

```text
Only CEG APIs mutate CEG.
Only command dispatcher applies edit commands.
Renderer and UI never mutate CEG directly.
Format adapters only create/import/export CEG.
```

## AI-0 quantitative pass tests

| Test | Required result |
|---|---|
| Contract files exist | 5/5 required contract docs present |
| Schema version exported | `CEG-1.0` |
| Event names frozen | No duplicate event names |
| Agent boundaries listed | 100% Wave 1 agents have file ownership table |
| Static violation regex drafted | Must catch `mesh.position`, `rawDxf`, direct `geometry.ep1 =` in UI paths |

---

# 3. AI-1 Work Instruction — CEG Kernel Owner

## Ownership

```text
core/ceg/canonical-edit-graph.js
core/ceg/canonical-component.js
core/ceg/canonical-anchor.js
core/ceg/topology-links.js
core/ceg/capabilities.js
core/ceg/loss-contract.js
core/ceg/source-refs.js
core/ceg/render-refs.js
core/ceg/ceg-hash.js
```

## Must not edit

```text
core/commands/*
core/geometry/*
formats/*
render/*
editor/*
ui/*
```

## Required implementation

### Canonical Edit Graph factory

```js
export function createCanonicalEditGraph(input = {}) {
  return {
    schemaVersion: "CEG-1.0",
    document: {
      id: input.id || "doc_001",
      name: input.name || "Untitled",
      units: input.units || "mm",
      sourceFormat: input.sourceFormat || "UNKNOWN",
      coordinateSystem: input.coordinateSystem || "WORLD_XYZ"
    },
    components: {},
    anchors: {},
    topologyLinks: [],
    layers: {},
    sourceRefs: {},
    renderRefs: {},
    diagnostics: [],
    lossContract: {
      unsupportedEntities: [],
      downgradedEntities: [],
      proxyEntities: [],
      exportWarnings: []
    },
    commandJournal: []
  };
}
```

### Component contract

```js
export function createComponent(input) {
  return {
    id: input.id,
    type: input.type,
    layerId: input.layerId || "default",
    anchorIds: input.anchorIds || [],
    geometryRole: input.geometryRole || "UNKNOWN",
    attributes: input.attributes || {},
    rawAttributes: input.rawAttributes || {},
    derived: input.derived || {},
    capabilities: input.capabilities || defaultCapabilities(input.type),
    diagnostics: input.diagnostics || []
  };
}
```

### Anchor contract

```js
export function createAnchor(input) {
  return {
    id: input.id,
    role: input.role,
    point: {
      x: Number(input.point?.x || 0),
      y: Number(input.point?.y || 0),
      z: Number(input.point?.z || 0)
    },
    connectedTo: input.connectedTo || [],
    locked: Boolean(input.locked),
    sourceRef: input.sourceRef || null
  };
}
```

### Default capability matrix

| Type | Move | Delete | Stretch | Extend | Export DXF | Export GLB |
|---|---:|---:|---:|---:|---:|---:|
| LINE | Yes | Yes | Yes | Yes | Yes | Yes |
| PIPE | Yes | Yes | Yes | Yes | Yes | Yes |
| ARC | Yes | Yes | No initially | No initially | Yes | Yes |
| BLOCK_COMPONENT | Yes | Yes | No | No | Yes | Yes |
| MESH_OBJECT | Yes | Yes | No | No | Proxy | Yes |
| PROXY_DXF_ENTITY | Yes | Yes | No | No | Proxy | Proxy |

## Mock required from AI-1

Create or validate:

```text
fixtures/mock-ceg-basic.json
```

It must contain:

```text
1 LINE component
2 anchors
1 BLOCK_COMPONENT
1 MESH_OBJECT
1 default layer
1 unsupported/proxy diagnostic
```

## AI-1 quantitative pass tests

| Test | Required result |
|---|---|
| Empty graph creation | Graph has all required top-level keys |
| Deterministic hash | Same input graph produces same hash 10/10 times |
| Add 10 components | component count = 10 |
| Add 20 anchors | anchor count = 20 |
| Component anchor validation | 100% anchorIds resolve |
| Missing anchor validation | Fails with diagnostic, not crash |
| Capability defaults | LINE can stretch/extend; MESH_OBJECT cannot |
| Loss contract present | unsupported/downgraded/proxy/exportWarnings arrays exist |

---

# 4. AI-2 Work Instruction — Command + Geometry Operations Owner

## Ownership

```text
core/commands/command-types.js
core/commands/command-dispatcher.js
core/commands/command-journal.js
core/commands/command-checkpoints.js
core/commands/geometry-commands.js
core/commands/property-commands.js

core/geometry/units.js
core/geometry/coordinate-system.js
core/geometry/vectors.js
core/geometry/anchors.js
core/geometry/linear-ops.js
core/geometry/arc-ops.js
core/geometry/bbox.js

core/validation/model-validator.js
core/validation/topology-validator.js
core/validation/export-validator.js
```

## Must not edit

```text
core/ceg/* except imports from public API
formats/*
render/*
editor/*
ui/*
```

## Required command types

```js
export const CommandType = Object.freeze({
  MOVE_COMPONENTS: "MOVE_COMPONENTS",
  MOVE_ANCHORS: "MOVE_ANCHORS",
  EXTEND_LINEAR: "EXTEND_LINEAR",
  STRETCH_ANCHORS: "STRETCH_ANCHORS",
  DELETE_COMPONENTS: "DELETE_COMPONENTS",
  SET_PROPERTY: "SET_PROPERTY",
  SET_LAYER_VISIBILITY: "SET_LAYER_VISIBILITY"
});
```

## Required dispatcher contract

```js
export function dispatchCommand(graph, command) {
  const beforeHash = hashCeg(graph);
  const next = applyCommand(graph, command);
  const afterHash = hashCeg(next);

  next.commandJournal.push({
    ...command,
    beforeHash,
    afterHash,
    timestamp: command.timestamp || 0
  });

  return validateAfterCommand(next, command);
}
```

## Required geometry behavior

### MOVE_ANCHORS

```text
Move only listed anchors by delta.
Do not move opposite anchor unless it is explicitly targeted.
Do not move locked anchors.
```

### MOVE_COMPONENTS

```text
Resolve all anchorIds for selected components.
Move all unlocked anchors by delta.
```

### EXTEND_LINEAR

```text
Allowed only when component.geometryRole = LINEAR.
Allowed only when component has exactly two anchors.
New length must be > 0.
Preserve direction from fixed endpoint to moving endpoint.
```

### STRETCH_ANCHORS

```text
Move selected endpoint anchors by delta.
Do not automatically move connected anchors in Wave 1.
If anchor has connectedTo entries, add warning diagnostic.
```

### DELETE_COMPONENTS

```text
Remove component.
Keep orphan anchors only if referenced by another component.
Invalidate renderRefs.
Record delete in command journal.
```

## Mock required from AI-2

Create or validate:

```text
fixtures/mock-command-sequence.json
```

Required sequence:

```text
MOVE_COMPONENTS line_001 by X=1000
EXTEND_LINEAR line_001 from 4200 to 5000
STRETCH_ANCHORS a2 by Z=-1200
DELETE_COMPONENTS block_001
UNDO last command
REDO last command
```

## AI-2 quantitative pass tests

| Test | Required result |
|---|---|
| Move line component X=1000 | both anchors shift X exactly +1000 |
| Move endpoint only | selected anchor moves; opposite anchor unchanged |
| Extend 4200 → 5000 | computed length = 5000 ± 0.001 |
| Stretch EP2 Z=-1200 | EP2.z changes by -1200; EP1 unchanged |
| Delete block_001 | component count decreases by 1 |
| Undo delete | graph hash equals pre-delete hash |
| Redo delete | graph hash equals post-delete hash |
| Locked anchor move | graph unchanged; diagnostic emitted |
| Unsupported extend on MESH_OBJECT | graph unchanged; diagnostic emitted |
| Command journal | one entry per successful command |

---

# 5. AI-9 Work Instruction — Wave 1 QA Owner

## Ownership

```text
tests/unit/ceg/*
tests/unit/commands/*
tests/fixtures/*
qa/evidence/wave-1/*
```

## Tasks

1. Create mock CEG fixture.
2. Create command sequence fixture.
3. Add pure unit tests for graph creation.
4. Add pure unit tests for commands.
5. Add hash consistency tests.
6. Add validation tests.
7. Add static boundary checks.

## Mock fixtures required

```text
fixtures/mock-ceg-basic.json
fixtures/mock-command-sequence.json
```

## Required static checks

Fail Wave 1 if any future UI/editor/render code contains final mutation patterns:

```text
mesh.position.
rawDxf.
rawGltf.
geometry.ep1 =
geometry.ep2 =
commandJournal.push outside core/commands
```

## Wave 1 final pass criteria

| Gate | Required result |
|---|---|
| CEG contract | Frozen and documented |
| Command contract | Frozen and documented |
| Unit tests | 100% pass |
| Hash tests | 100% deterministic |
| Command journal | Present and tested |
| Undo/redo | Hash restoration confirmed |
| Static violation scan | 0 violations |
| Mock fixtures | Present and used by tests |
| Wave 2 unblock | AI-3/AI-4/AI-5 receive stable adapter API |

---

# 6. Wave 1 “done” definition

Wave 1 is complete only when this exact scenario passes:

```text
Load mock-ceg-basic.json
Move line_001 by X=1000
Extend line_001 to 5000
Stretch anchor a2 by Z=-1200
Delete block_001
Undo delete
Redo delete
Validate graph
Check command journal
Check graph hash before/after
```

Expected quantitative result:

```text
line_001 anchor a1.x = 1000
line_001 anchor a2.x = 6000 after extend
line_001 anchor a2.z = -1200 after stretch
block_001 removed after redo
commandJournal length >= 4
validation errors = 0
validation warnings allowed <= 1 for connected-anchor stretch
```
