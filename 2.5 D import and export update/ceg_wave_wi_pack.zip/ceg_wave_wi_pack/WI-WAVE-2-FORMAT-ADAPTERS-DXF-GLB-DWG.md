# WI — Wave 2: Format Adapters — DXF, GLB/GLTF, Optional DWG Converter

## Wave 2 mission

Build import/export adapters that translate external files into the Canonical Edit Graph and back out again.

```text
DXF → RawDXFModel → CEG → DXF
GLB/GLTF → RawGLTFScene → CEG → GLB
DWG → optional converter → DXF → CEG
```

Wave 2 must not implement interactive editing, HUD, toolbar behavior, or rendering internals. It proves that external formats can enter and exit the CEG reliably.

---

# 1. Agents grouped in Wave 2

| Agent | Role | Can run together? | Dependency |
|---|---|---:|---|
| AI-3 | DXF Adapter Owner | Yes | Wave 1 CEG + command contracts |
| AI-4 | GLB/GLTF Adapter Owner | Yes | Wave 1 CEG + capability contract |
| AI-5 | DWG Converter Client Owner | Yes | AI-3 DXF intake interface |
| AI-9 | QA / Round-trip Owner | Yes | Wave 1 fixtures + adapter APIs |

## Parallelization rule

AI-3 and AI-4 can run in parallel because they touch different directories. AI-5 can run in parallel as long as it does not modify DXF parser/export files. AI-9 starts immediately with mock fixtures and adds integration tests as adapters land.

---

# 2. AI-3 Work Instruction — DXF Adapter Owner

## Ownership

```text
formats/dxf/dxf-preflight.js
formats/dxf/dxf-parser-adapter.js
formats/dxf/dxf-worker.js
formats/dxf/dxf-raw-model.js
formats/dxf/dxf-layer-resolver.js
formats/dxf/dxf-block-resolver.js
formats/dxf/dxf-to-ceg.js
formats/dxf/ceg-to-dxf.js
formats/dxf/dxf-loss-contract.js
tests/roundtrip/dxf-roundtrip.test.js
```

## Must not edit

```text
formats/gltf/*
formats/dwg/*
core/commands/*
render/*
editor/*
ui/*
```

## Required pipeline

```text
DXF file/string
  ↓
preflight
  ↓
parser adapter
  ↓
RawDXFModel
  ↓
layer/block/entity resolver
  ↓
dxfToCeg()
  ↓
CEG
```

## DXF preflight requirements

Return:

```js
{
  fileSizeBytes,
  estimatedLineCount,
  estimatedEntityCount,
  estimatedLayerCount,
  estimatedBlockCount,
  estimatedTextCount,
  loadMode: "NORMAL" | "LARGE_FILE" | "LAYER_GATED"
}
```

Thresholds:

```text
< 5 MB       → NORMAL
5–50 MB      → LARGE_FILE
> 50 MB      → LAYER_GATED
```

## Required mappings

| DXF entity | CEG mapping |
|---|---|
| LINE | LINE component with EP1/EP2 anchors |
| LWPOLYLINE / POLYLINE | multiple LINE components or POLYLINE component |
| ARC | ARC component with EP1/EP2/CP anchors where derivable |
| INSERT | BLOCK_COMPONENT |
| ATTRIB | component attributes |
| TEXT / MTEXT | ANNOTATION component |
| Unsupported | PROXY_DXF_ENTITY + lossContract entry |

## Source preservation

Every DXF-derived component must preserve:

```js
sourceRef: {
  format: "DXF",
  handle,
  entityType,
  layer,
  blockName,
  vertexIndex
}
```

## DXF confidence scoring

```text
1.00 explicit block/attribute metadata
0.80 strong layer + block name match
0.60 geometry pattern + nearby text
0.30 geometry only
0.10 unknown proxy
```

## Export requirement

`cegToDxf(graph)` must export only from CEG, never from the original raw DXF model.

Minimum export support:

```text
LINE → DXF LINE
ARC → DXF ARC if radius/center are valid
BLOCK_COMPONENT → INSERT fallback or simple symbol block
ANNOTATION → TEXT
PROXY_DXF_ENTITY → proxy layer note or preserved fallback where possible
```

## Mock required from AI-3

Use/create:

```text
fixtures/mock-dxf-basic-lines.dxf
```

Required content:

```text
2 LINE entities
1 ARC entity
1 TEXT entity
at least 1 LAYER
```

## AI-3 quantitative pass tests

| Test | Required result |
|---|---|
| Import mock DXF | At least 4 CEG components |
| 2 LINE entities | Exactly 2 LINE components |
| LINE source handle/layer | Preserved in sourceRefs |
| ARC import | ARC component created with valid radius or diagnostic |
| TEXT import | ANNOTATION component created |
| Unsupported entity | PROXY + lossContract entry |
| Move imported line using Wave 1 command | CEG updates |
| Export DXF | Output string contains moved LINE coordinates |
| Reimport exported DXF | Coordinate tolerance ≤ 0.001 mm |
| Large-file mode trigger | File size threshold returns correct loadMode |

---

# 3. AI-4 Work Instruction — GLB/GLTF Adapter Owner

## Ownership

```text
formats/gltf/gltf-loader-adapter.js
formats/gltf/gltf-metadata-reader.js
formats/gltf/gltf-to-ceg.js
formats/gltf/ceg-to-gltf.js
formats/gltf/gltf-optimizer-hints.js
formats/gltf/gltf-disposal-manager.js
tests/roundtrip/gltf-roundtrip.test.js
```

## Must not edit

```text
formats/dxf/*
formats/dwg/*
core/commands/*
render/*
editor/*
ui/*
```

## Required pipeline

```text
GLB/GLTF file
  ↓
GLTFLoader adapter
  ↓
RawGLTFScene
  ↓
metadata reader
  ↓
gltfToCeg()
  ↓
CEG
```

## Classification rules

| GLB/GLTF object | CEG type | Capabilities |
|---|---|---|
| userData/extras says PIPE and endpoints exist | PIPE | move/delete/stretch/extend |
| userData/extras says component, no endpoints | BLOCK_COMPONENT | move/delete |
| generic mesh | MESH_OBJECT | move/delete |
| inferred cylinder | MESH_PIPE_CANDIDATE | move/delete; stretch disabled until confirmed |
| equipment mesh | MESH_OBJECT | move/delete |
| unknown | MESH_OBJECT with diagnostic | move/delete |

## Metadata extraction priority

```text
1. node.userData.glbPcfEditor
2. glTF extras
3. node name
4. mesh name
5. material name
6. bounding box / geometry inference
```

## Required GLB metadata on export

```js
node.userData.glbPcfEditor = {
  schemaVersion: "1.0",
  canonicalId: component.id,
  componentType: component.type,
  lineNo: component.attributes?.lineNo || null,
  size: component.attributes?.size || null,
  spec: component.attributes?.spec || null,
  sourceFormat: component.sourceRef?.format || "CEG"
};
```

## Disposal manager requirements

When unloading/reloading GLB:

```text
dispose geometries
dispose materials
dispose textures
clear object-to-component index references
emit disposal diagnostic summary
```

## Mock required from AI-4

Use/create:

```text
fixtures/mock-gltf-scene.json
```

Required content:

```text
1 metadata-rich PIPE node with EP1/EP2
1 generic mesh node
1 valve-like block component node
1 unknown mesh node
```

## AI-4 quantitative pass tests

| Test | Required result |
|---|---|
| Import metadata-rich PIPE | PIPE component with 2 anchors |
| PIPE capabilities | canMove/canDelete/canStretch/canExtend = true |
| Generic mesh import | MESH_OBJECT component |
| Generic mesh capabilities | canMove/canDelete = true; canStretch/canExtend = false |
| Unknown mesh | Diagnostic emitted, no crash |
| Export GLB/metadata mock | canonicalId preserved |
| Reimport exported metadata | canonicalId matches original |
| Stretch generic mesh | blocked with diagnostic |
| Disposal run | zero retained disposed object refs in adapter-owned index |

---

# 4. AI-5 Work Instruction — DWG Converter Client Owner

## Ownership

```text
formats/dwg/dwg-conversion-client.js
formats/dwg/dwg-conversion-status.js
formats/dwg/dwg-experimental-browser.js
formats/dwg/dwg-diagnostics.js
ui/import-panel/dwg-import-status.js
tests/roundtrip/dwg-converter.test.js
```

## Must not edit

```text
formats/dxf/dxf-to-ceg.js
formats/dxf/ceg-to-dxf.js
formats/gltf/*
core/commands/*
render/*
editor/*
```

## Required behavior

DWG is **not** edited natively. It is converted to DXF or canonical JSON first.

```text
DWG file
  ↓
converter health check
  ↓
converter unavailable → show message
  ↓
converter available → convert to DXF
  ↓
pass DXF to DXF adapter
```

## Converter endpoints

```text
GET  /health
POST /convert/dwg-to-dxf
POST /convert/dwg-to-json
```

## Required unavailable message

```text
DWG conversion service is not configured.
Please convert DWG to DXF and import the DXF file.
```

## Mock required from AI-5

Use/create:

```text
fixtures/mock-dwg-converter-response.json
```

Required shape:

```json
{
  "ok": true,
  "source": "sample.dwg",
  "targetFormat": "DXF",
  "engine": "MockConverter",
  "warnings": [],
  "diagnostics": {},
  "contentBase64": "..."
}
```

## AI-5 quantitative pass tests

| Test | Required result |
|---|---|
| Converter unavailable | No crash; exact unavailable message shown |
| `/health` false | Import panel remains usable |
| Converter success | DXF adapter receives decoded DXF content |
| Converter failure | Diagnostic shown |
| Browser experimental DWG | Disabled by default |
| DWG path | Never mutates CEG directly; always routes through DXF or canonical JSON |

---

# 5. AI-9 Work Instruction — Wave 2 QA Owner

## Ownership

```text
tests/roundtrip/dxf-roundtrip.test.js
tests/roundtrip/gltf-roundtrip.test.js
tests/roundtrip/dwg-converter.test.js
tests/fixtures/*
qa/evidence/wave-2/*
```

## Required round-trip scenarios

### DXF scenario

```text
Import mock-dxf-basic-lines.dxf
CEG created
Move first LINE by X=1000
Export DXF
Reimport exported DXF
Verify first line X coordinates shifted by +1000
```

### GLB/GLTF scenario

```text
Import mock-gltf-scene.json
CEG created
Move metadata-rich PIPE by X=1000
Export metadata
Reimport metadata
Verify canonicalId and transform preserved
```

### DWG scenario

```text
Try DWG import with converter disabled
Verify no crash
Verify unavailable message
Run mock converter response
Verify decoded DXF is sent to DXF adapter
```

## Wave 2 final pass criteria

| Gate | Required result |
|---|---|
| DXF import | Mock DXF creates valid CEG |
| DXF export | Reimport coordinate tolerance ≤ 0.001 mm |
| GLB import | Metadata-rich and generic mesh paths both work |
| GLB export | canonicalId preserved |
| DWG fallback | No crash without converter |
| Adapter boundary | 0 UI/render direct mutations |
| Loss contract | Unsupported DXF/GLB items produce diagnostics |
| Static compatibility | Adapter code has no mandatory backend except optional DWG converter |

---

# 6. Wave 2 “done” definition

Wave 2 is complete only when:

```text
DXF → CEG → command edit → DXF → CEG passes
GLB mock → CEG → command edit → GLB metadata mock → CEG passes
DWG unavailable path is graceful
DWG mock converter path reaches DXF adapter
All unsupported content is reported in lossContract/diagnostics
```
