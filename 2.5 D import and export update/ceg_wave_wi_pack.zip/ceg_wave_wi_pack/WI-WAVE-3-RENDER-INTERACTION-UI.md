# WI — Wave 3: Render Projection + Interaction/HUD + Panels/UI Shell

## Wave 3 mission

Connect the CEG and adapters to the visible app without breaking the model boundary.

```text
CEG
  ↓
Render Projection Index
  ↓
Selectable scene objects + grips + labels
  ↓
Interaction / HUD / keyboard
  ↓
Panels / toolbar / import-export UI
  ↓
Smoke tests
```

Wave 3 must not invent new CEG schema, command types, or format adapter behavior. It consumes Wave 1 and Wave 2 contracts.

---

# 1. Agents grouped in Wave 3

| Agent | Role | Can run together? | Dependency |
|---|---|---:|---|
| AI-6 | Render Projection Owner | Starts first in Wave 3 | Wave 1 CEG |
| AI-7 | Interaction / Grips / HUD Owner | Starts after render index skeleton | AI-6 render contract |
| AI-8 | Panels / UI Shell Owner | Starts parallel with AI-7 after event contract | AI-0 event contract |
| AI-9 | Static smoke / behavior QA | Starts with AI-6 and continues | Wave 1–2 fixtures |

## Parallelization rule

AI-7 and AI-8 can run in parallel only after AI-6 publishes:

```text
render/render-index.js
render/render-projection.js
render/RENDER_CONTRACT.md
```

---

# 2. AI-6 Work Instruction — Render Projection Owner

## Ownership

```text
render/render-projection.js
render/render-index.js
render/component-renderer.js
render/grip-renderer.js
render/label-renderer.js
render/selection-renderer.js
render/large-model-renderer.js
tests/unit/render-index.test.js
```

## Must not edit

```text
core/commands/*
formats/*
editor/*
ui/property-panel/*
ui/edit-hud/*
```

## Required architecture

The renderer is a projection, not the model.

```text
CEG component/anchor/layer
  ↓
render object/body/grip/label/helper
  ↓
renderIndex maps both directions
```

## Render index contract

```js
export function createRenderIndex() {
  return {
    componentToObjects: new Map(),
    objectToComponent: new WeakMap(),
    anchorToGrip: new Map(),
    layerToObjects: new Map()
  };
}
```

## Required userData

Every selectable body object:

```js
object.userData.canonicalId = component.id;
object.userData.renderRole = "BODY";
```

Every grip:

```js
grip.userData.canonicalId = component.id;
grip.userData.anchorId = anchor.id;
grip.userData.renderRole = "GRIP";
```

Every label:

```js
label.userData.canonicalId = component.id;
label.userData.renderRole = "LABEL";
```

## Required render roles

```text
BODY
GRIP
LABEL
HELPER
PREVIEW
```

## Render update rules

| Event | Renderer action |
|---|---|
| `ceg:model-loaded` | Build full projection |
| `ceg:model-changed` | Update affected components or rebuild if unknown |
| `ceg:selection-changed` | Update highlight/selection overlay |
| Layer visibility changed | Hide/show render objects only; do not delete CEG |

## AI-6 quantitative pass tests

| Test | Required result |
|---|---|
| Render mock CEG | Body object for every visible component |
| Every body | has `userData.canonicalId` |
| Linear component | has 2 grips for EP1/EP2 |
| Delete component event | body/grips/labels removed |
| Undo delete event | body/grips/labels restored |
| Layer hide | render objects hidden; CEG unchanged |
| Render orphan check | 0 orphan body/grip/label objects |
| Object pick | object maps back to canonicalId |

---

# 3. AI-7 Work Instruction — Interaction / Grips / HUD Owner

## Ownership

```text
editor/active-tool-controller.js
editor/selection-controller.js
editor/grip-interaction.js
editor/hud-lite.js
editor/keyboard-shortcuts.js
editor/snap-lite.js
editor/drag-preview.js
tests/unit/editor-interaction.test.js
```

## Must not edit

```text
core/commands/* except imports
render/render-index.js
formats/*
ui/property-panel/*
```

## Required active tools

```text
SELECT
MOVE
MOVE_ANCHOR
EXTEND
STRETCH
DELETE
```

## Required interaction flow

```text
Pointer down on render object
  ↓
renderIndex gives canonicalId / anchorId
  ↓
selection controller updates selection
  ↓
HUD displays relevant numeric fields
  ↓
drag creates preview only
  ↓
Enter / mouse-up commit dispatches command
```

## HUD-lite fields

For linear component:

```text
Selected component ID
Selected anchor ID
Current length
New length
ΔX
ΔY
ΔZ
Enter = apply
Esc = cancel
```

## Required command dispatches

| User action | Command |
|---|---|
| Drag whole component | MOVE_COMPONENTS |
| Drag endpoint grip | MOVE_ANCHORS |
| HUD new length | EXTEND_LINEAR |
| HUD ΔX/ΔY/ΔZ for anchor | STRETCH_ANCHORS |
| Delete key | DELETE_COMPONENTS |

## Forbidden pattern

```js
mesh.position.x += dx;
graph.anchors[a2].point.z -= 1200;
rawDxf.entities[i].vertices[0] = point;
```

## Required pattern

```js
dispatchCommand(graph, {
  type: CommandType.STRETCH_ANCHORS,
  target: ["a2"],
  payload: {
    delta: { x: 0, y: 0, z: -1200 }
  }
});
```

## AI-7 quantitative pass tests

| Test | Required result |
|---|---|
| Click body | selection contains component ID |
| Click grip | selection contains anchor ID |
| Drag EP2 preview | CEG unchanged before commit |
| Mouse-up after grip drag | dispatches MOVE_ANCHORS |
| HUD ΔZ=-1200 + Enter | dispatches STRETCH_ANCHORS |
| Esc during drag | preview removed; CEG unchanged |
| Delete key | dispatches DELETE_COMPONENTS |
| Unsupported stretch target | HUD disabled reason shown |

---

# 4. AI-8 Work Instruction — Panels / UI Shell Owner

## Ownership

```text
ui/property-panel/*
ui/layer-panel/*
ui/debug-panel/*
ui/import-panel/*
ui/export-panel/*
ui/toolbar-wiring.js
ui/status-bar.js
tests/unit/ui-panels.test.js
```

## Must not edit

```text
core/commands/*
render/*
formats/*
editor/grip-interaction.js
```

## Required panels

### Property panel

Displays selected component:

```text
Identity
Geometry / anchors
Attributes
Capabilities
Source refs
Diagnostics
```

Property edits must dispatch commands only.

### Layer panel

```text
Layer name
Visibility
Object count
Source format count
```

Layer visibility uses `SET_LAYER_VISIBILITY`.

### Debug panel

Displays:

```text
CEG component count
anchor count
topology link count
render body count
grip count
label count
selected IDs
command journal length
loss contract
validation errors/warnings
orphan render object count
```

### Import panel

Routes:

```text
.dxf → DXF adapter
.glb/.gltf → GLB/GLTF adapter
.dwg → DWG converter client
.json/.pcfx → CEG/PCFX importer where available
```

### Export panel

Routes:

```text
Export DXF → CEG-to-DXF
Export GLB → CEG-to-GLB
Export JSON/PCFX → CEG serializer
```

## Required toolbar behavior

Toolbar only changes active tool or calls command dispatcher. It must not mutate renderer, CEG internals, raw DXF, or raw GLB.

```js
toolbar.onMove = () => activeToolController.setTool("MOVE");

toolbar.onDelete = () => dispatchCommand(graph, {
  type: CommandType.DELETE_COMPONENTS,
  target: selectionController.selectedComponentIds()
});
```

## AI-8 quantitative pass tests

| Test | Required result |
|---|---|
| Select component | property panel shows canonicalId |
| Edit anchor X field | dispatches SET_PROPERTY or MOVE_ANCHORS |
| Toolbar Move | active tool changes; graph unchanged |
| Toolbar Delete | dispatches DELETE_COMPONENTS |
| Layer hide | dispatches SET_LAYER_VISIBILITY |
| Debug after mock render | body/grip counts match render index |
| Import .dwg without converter | shows required message |
| Export DXF | exporter receives CEG, not raw DXF |

---

# 5. AI-9 Work Instruction — Wave 3 QA Owner

## Ownership

```text
tests/smoke/static-smoke.test.js
tests/smoke/basic-edit-flow.test.js
tests/e2e/dxf-basic-editor-flow.test.js
tests/e2e/glb-basic-editor-flow.test.js
qa/evidence/wave-3/*
```

## Required smoke scenarios

### Static app smoke

```text
Open static build
Load mock CEG
No console errors
Render scene
Select object
Show property panel
```

### Basic edit flow

```text
Load mock CEG
Select LINE component
Move by X=1000
Stretch EP2 by Z=-1200
Delete BLOCK_COMPONENT
Undo delete
Redo delete
Render index remains clean
```

### DXF visible flow

```text
Import mock DXF
Render LINE components
Select first line
Move
Export DXF
No crash
```

### GLB visible flow

```text
Import mock GLTF scene
Render metadata-rich pipe and generic mesh
Move both
Stretch only metadata-rich pipe
Generic mesh stretch blocked
```

## Wave 3 final pass criteria

| Gate | Required result |
|---|---|
| Render projection | 0 orphan objects |
| Selection | picked object maps to canonicalId |
| Grips | anchors map to grip objects |
| HUD | dispatches commands only |
| Property panel | dispatches commands only |
| Toolbar | no direct mutation |
| Debug panel | shows model/render/loss/command data |
| Static smoke | no backend required |
| Console errors | 0 uncaught errors |
| Import/export buttons | route to adapters without raw mutation |

---

# 6. Wave 3 “done” definition

Wave 3 is complete only when this visual behavior works:

```text
Open static app
Load mock CEG
Render one line, one block, one mesh
Select line body
Show property panel
Show two endpoint grips
Drag EP2 preview
Commit stretch by Z=-1200
Render line updates
Debug panel shows 0 orphan render objects
Export DXF/GLB buttons route to CEG exporters
Delete block
Undo/redo delete
No console errors
```

Expected quantitative result:

```text
body objects = visible components
grip objects = editable anchors
orphan render objects = 0
invalid selected IDs = 0 after delete
commandJournal length increases by each committed edit
generic mesh canMove = true
generic mesh canStretch = false
```
